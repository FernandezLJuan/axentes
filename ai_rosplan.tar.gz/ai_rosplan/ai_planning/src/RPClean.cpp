#include "ai_planning/RPClean.h"

namespace KCL_rosplan {

    // constructor
    RPClean::RPClean(ros::NodeHandle &nh) {
        nh_ = nh;
    }

    bool RPClean::concreteCallback(const rosplan_dispatch_msgs::ActionDispatch::ConstPtr& msg) {
        
	    ROS_INFO_STREAM("LIMPIO PIBE");

        ros::Publisher velocity_publisher = nh_.advertise<geometry_msgs::Twist>("/cmd_vel_mux/input/navi",1); 
        geometry_msgs::Twist velocidad;

        velocidad.linear.x=0;
        velocidad.angular.z=3.14;

        velocity_publisher.publish(velocidad);

        ros::Rate rate(1);
        rate.sleep();
        
        return true;
    }
    
} // close namespace

int main(int argc, char **argv) {

    ros::init(argc, argv, "rosplan_interface_clean");

    ros::NodeHandle nh("~");

    // create PDDL action subscriber
    KCL_rosplan::RPClean rpmb(nh);

    rpmb.runActionInterface();

    return 0;
}
